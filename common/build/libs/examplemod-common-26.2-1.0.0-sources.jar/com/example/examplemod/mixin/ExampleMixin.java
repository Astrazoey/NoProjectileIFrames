package com.example.examplemod.mixin;

import org.spongepowered.asm.mixin.Mixin;

/**
 * Template mixin — replace with your actual mixin target and logic.
 * <p>
 * This example targets nothing. To use it:
 * 1. Change the @Mixin target to a vanilla class
 * 2. Add your injection methods
 * 3. Register the mixin in examplemod.mixins.json
 */
@Mixin(Object.class)
public class ExampleMixin {
    // Add your mixin injections here
}
